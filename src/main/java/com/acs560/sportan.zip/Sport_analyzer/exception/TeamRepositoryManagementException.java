package com.acs560.Sport_analyzer.exception;

public class TeamRepositoryManagementException extends RuntimeException {

    private static final long serialVersionUID = -8364712614855191768L;

    public TeamRepositoryManagementException(String msg) {
        super(msg);
    }
}
